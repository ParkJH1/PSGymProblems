# 솔루션

문자열로 입력받아서 그대로 출력한다.



# 소스코드

```cpp
#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    while(n--){
        string s;
        cin>>s;
        cout<<s;
    }
    return 0;
}
```
