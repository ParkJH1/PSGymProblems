#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    while(n--){
        string s;
        cin>>s;
        cout<<s;
    }
    return 0;
}
