# 솔루션

이중 for문으로 구현한다.



# 소스코드

```cpp
#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        for(int j=0; j<=i; j++) cout<<"*";
        cout<<"\n";
    }
    return 0;
}
```
