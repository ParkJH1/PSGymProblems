# 솔루션

a + b를 출력한다



# 소스코드

```cpp
#include <iostream>
using namespace std;
int main()
{
    int a,b;
    cin>>a>>b;
    cout<<a+b;
    return 0;
}
```
