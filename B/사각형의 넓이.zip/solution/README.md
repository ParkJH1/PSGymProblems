# 솔루션

사각형의 넓이는 가로 x 세로다.

W * H 를 출력한다.



# 소스코드

```cpp
#include <iostream>
using namespace std;
int main()
{
    int w,h;
    cin>>w>>h;
    cout<<w*h;
    return 0;
}
```
