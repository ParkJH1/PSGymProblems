#include <iostream>
using namespace std;
int main()
{
    int w,h;
    cin>>w>>h;
    cout<<w*h;
    return 0;
}
